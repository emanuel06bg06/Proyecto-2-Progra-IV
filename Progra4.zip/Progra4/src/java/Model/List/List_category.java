package Model.List;

import Modelo.Category;
import java.io.Serializable;
import java.util.ArrayList;

public class List_category extends ArrayList<Category> implements Serializable {

}
