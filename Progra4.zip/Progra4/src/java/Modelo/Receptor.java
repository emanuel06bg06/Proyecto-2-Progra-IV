package Modelo;

import java.io.Serializable;

public class Receptor implements Serializable {
				
}
